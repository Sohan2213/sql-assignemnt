Select ctry.continent, floor(avg(city.population))
from city city
join country ctry on city.countrycode = ctry.code
group by ctry.continent;
